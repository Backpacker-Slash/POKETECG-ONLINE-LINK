INCLUDE "data/auto_deck_card_lists.asm"
INCLUDE "data/auto_deck_machines.asm"

; NUM_AUTO_DECKS_TO_INITIALIZE EQU 20

; initialize the first 20 Deck Save Machine slots
; from the first 20 Auto Deck Machine configurations
InitSavedDecksFromAutoDecks:
	call EnableSRAM

	ld hl, AutoDeckMachineEntries
	ld b, 0 ; Auto Deck entry index
	ld c, 20;NUM_AUTO_DECKS_TO_INITIALIZE

.loop
	call .GetPointerToSavedDeck

	call ReadDeckConfigurationFromAutoDeckEntry
	call ReadDeckNameFromAutoDeckEntry

	; entry layout is:
	; 2 bytes card-list pointer
	; 2 bytes name text ID
	; 2 bytes description text ID
	;
	; helpers consumed the first 4 bytes,
	; so skip the description.
	inc hl
	inc hl

	inc b
	dec c
	jr nz, .loop

	call DisableSRAM
	ret

; DE = sSavedDecks + (B * DECK_STRUCT_SIZE)
.GetPointerToSavedDeck:
	push hl
	push bc

	ld l, b
	ld h, DECK_STRUCT_SIZE
	call HtimesL

	ld de, sSavedDecks
	add hl, de
	ld d, h
	ld e, l

	pop bc
	pop hl
	ret

; writes the deck configuration in SRAM
; HL = pointer to an AutoDeckMachineEntries entry
; DE = destination deck_struct
; returns HL advanced by 2 bytes
ReadAutoDeckConfiguration:
	call EnableSRAM
	ld a, [wCurAutoDeckMachine]
	ld l, a
	ld h, 6 * NUM_DECK_MACHINE_SLOTS
	call HtimesL
	ld bc, AutoDeckMachineEntries
	add hl, bc
	ld b, 0
.loop_decks
	call .GetPointerToSRAMAutoDeck
	call ReadDeckConfigurationFromAutoDeckEntry
	call ReadDeckNameFromAutoDeckEntry

	; store deck description text ID
	push hl
	ld de, wAutoDeckMachineTextDescriptions
	ld h, b
	ld l, 2
	call HtimesL
	add hl, de
	ld d, h
	ld e, l
	pop hl
	ld a, [hli]
	ld [de], a
	inc de
	ld a, [hli]
	ld [de], a
	inc b
	ld a, b
	cp NUM_DECK_MACHINE_SLOTS
	jr nz, .loop_decks
	call DisableSRAM
	ret

; outputs in de the saved deck with index b
.GetPointerToSRAMAutoDeck
	push hl
	ld l, b
	ld h, DECK_STRUCT_SIZE
	call HtimesL
	ld de, sAutoDecks
	add hl, de
	ld d, h
	ld e, l
	pop hl
	ret

; writes the deck configuration in SRAM
; HL = pointer to an AutoDeckMachineEntries entry
; DE = destination deck_struct
; returns HL advanced by 2 bytes
ReadDeckConfigurationFromAutoDeckEntry::
	push hl
	push bc
	push de
	push de
	ld e, [hl]
	inc hl
	ld d, [hl]
	pop hl
	ld bc, DECK_NAME_SIZE
	add hl, bc
.loop_create_deck
	ld a, [de]
	inc de
	ld b, a ; card count
	or a
	jr z, .done_create_deck
	ld a, [de]
	inc de
	ld c, a ; card ID
.loop_card_count
	ld [hl], c
	inc hl
	dec b
	jr nz, .loop_card_count
	jr .loop_create_deck
.done_create_deck
	pop de
	pop bc
	pop hl
	inc hl
	inc hl
	ret

; copies the deck name from the AutoDeckMachineEntries entry
; into the destination deck_struct
; HL = pointer to the name text ID (entry + 2)
; DE = destination deck_struct
; returns HL advanced by 2 bytes	
ReadDeckNameFromAutoDeckEntry::
	push hl
	push bc
	push de
	ld a, [hli]
	ld h, [hl]
	ld l, a
	ld de, wDismantledDeckName
	call CopyText
	pop hl
	ld de, wDismantledDeckName
.loop_copy_name
	ld a, [de]
	ld [hli], a
	or a
	jr z, .done_copy_name
	inc de
	jr .loop_copy_name
.done_copy_name
	pop bc
	pop hl
	inc hl
	inc hl
	ret

; tries out all combinations of dismantling the player's decks
; in order to build the deck in wSelectedDeckMachineEntry
; if none of the combinations work, return carry set
; otherwise, return in a which deck flags should be dismantled
CheckWhichDecksToDismantleToBuildSavedDeck:
	xor a
	ld [wDecksToBeDismantled], a

; first check if it can be built by
; only dismantling a single deck
	ld a, DECK_1
.loop_single_built_decks
	call .CheckIfCanBuild
	ret nc
	sla a ; next deck
	cp (1 << NUM_DECKS)
	jr z, .two_deck_combinations
	jr .loop_single_built_decks

.two_deck_combinations
; next check all two deck combinations
	ld a, DECK_1 | DECK_2
	call .CheckIfCanBuild
	ret nc
	ld a, DECK_1 | DECK_3
	call .CheckIfCanBuild
	ret nc
	ld a, DECK_1 | DECK_4
	call .CheckIfCanBuild
	ret nc
	ld a, DECK_2 | DECK_3
	call .CheckIfCanBuild
	ret nc
	ld a, DECK_2 | DECK_4
	call .CheckIfCanBuild
	ret nc
	ld a, DECK_3 | DECK_4
	call .CheckIfCanBuild
	ret nc

; all but one deck combinations
	ld a, $ff ^ DECK_4
.loop_three_deck_combinations
	call .CheckIfCanBuild
	ret nc
	sra a
	cp $ff
	jr z, .all_decks
	jr .loop_three_deck_combinations

.all_decks
; finally check if can be built by dismantling all decks
	call .CheckIfCanBuild
	ret nc

; none of the combinations work
	scf
	ret

; returns carry if wSelectedDeckMachineEntry cannot be built
; by dismantling the decks given by register a
; a = DECK_* flags
.CheckIfCanBuild
	push af
	ld hl, wSelectedDeckMachineEntry
	ld b, [hl]
	farcall CheckIfCanBuildSavedDeck
	jr c, .cannot_build
	pop af
	ld [wDecksToBeDismantled], a
	or a
	ret
.cannot_build
	pop af
	scf
	ret
