; \1 = gfx pointer
; \2 = number of tiles
MACRO gfx_pointer
	dwb \1, BANK(\1) - BANK(Sprites)
	db \2
ENDM

Sprites:
	table_width 4
	; gfx_pointer OWPlayerGfx,         $14 ; SPRITE_OW_PLAYER
	; gfx_pointer OWRonaldGfx,         $14 ; SPRITE_OW_RONALD
	; gfx_pointer OWDrMasonGfx,        $14 ; SPRITE_OW_DRMASON
	; gfx_pointer OWIshiharaGfx,       $14 ; SPRITE_OW_ISHIHARA
	; gfx_pointer OWImakuniGfx,        $14 ; SPRITE_OW_IMAKUNI
	; gfx_pointer OWNikkiGfx,          $14 ; SPRITE_OW_NIKKI
	; gfx_pointer OWRickGfx,           $14 ; SPRITE_OW_RICK
	; gfx_pointer OWKenGfx,            $14 ; SPRITE_OW_KEN
	; gfx_pointer OWAmyGfx,            $1b ; SPRITE_OW_AMY
	; gfx_pointer OWIsaacGfx,          $14 ; SPRITE_OW_ISAAC
	; gfx_pointer OWMitchGfx,          $14 ; SPRITE_OW_MITCH
	; gfx_pointer OWGeneGfx,           $14 ; SPRITE_OW_GENE
	; gfx_pointer OWMurrayGfx,         $14 ; SPRITE_OW_MURRAY
	; gfx_pointer OWCourtneyGfx,       $14 ; SPRITE_OW_COURTNEY
	; gfx_pointer OWSteveGfx,          $14 ; SPRITE_OW_STEVE
	; gfx_pointer OWJackGfx,           $14 ; SPRITE_OW_JACK
	; gfx_pointer OWRodGfx,            $14 ; SPRITE_OW_ROD
	; gfx_pointer OWBoyGfx,            $14 ; SPRITE_OW_BOY
	; gfx_pointer OWLadGfx,            $14 ; SPRITE_OW_LAD
	; gfx_pointer OWSpecsGfx,          $14 ; SPRITE_OW_SPECS
	; gfx_pointer OWButchGfx,          $14 ; SPRITE_OW_BUTCH
	; gfx_pointer OWManiaGfx,          $14 ; SPRITE_OW_MANIA
	; gfx_pointer OWJoshuaGfx,         $14 ; SPRITE_OW_JOSHUA
	; gfx_pointer OWHoodGfx,           $14 ; SPRITE_OW_HOOD
	; gfx_pointer OWTechGfx,           $14 ; SPRITE_OW_TECH
	; gfx_pointer OWChapGfx,           $14 ; SPRITE_OW_CHAP
	; gfx_pointer OWManGfx,            $14 ; SPRITE_OW_MAN
	; gfx_pointer OWPappyGfx,          $14 ; SPRITE_OW_PAPPY
	; gfx_pointer OWGirlGfx,           $14 ; SPRITE_OW_GIRL
	; gfx_pointer OWLass1Gfx,          $14 ; SPRITE_OW_LASS1
	; gfx_pointer OWLass2Gfx,          $14 ; SPRITE_OW_LASS2
	; gfx_pointer OWLass3Gfx,          $14 ; SPRITE_OW_LASS3
	; gfx_pointer OWSwimmerGfx,        $14 ; SPRITE_OW_SWIMMER
	; gfx_pointer OWClerkGfx,          $08 ; SPRITE_OW_CLERK
	; gfx_pointer OWGalGfx,            $14 ; SPRITE_OW_GAL
	; gfx_pointer OWWomanGfx,          $14 ; SPRITE_OW_WOMAN
	; gfx_pointer OWGrannyGfx,         $14 ; SPRITE_OW_GRANNY
	; gfx_pointer OverworldMapOAMGfx,  $08 ; SPRITE_OW_MAP_OAM
	; gfx_pointer OWTorchGfx,          $16 ; SPRITE_OW_TORCH
	; gfx_pointer OWLegendaryCardGfx,  $0a ; SPRITE_OW_LEGENDARY_CARD
	gfx_pointer DuelGlowGfx,         $0b ; SPRITE_DUEL_GLOW
	gfx_pointer DuelParalysisGfx,    $06 ; SPRITE_DUEL_PARALYSIS
	gfx_pointer DuelSleepGfx,        $08 ; SPRITE_DUEL_SLEEP
	gfx_pointer DuelStarGfx,         $02 ; SPRITE_DUEL_STAR
	gfx_pointer DuelPoisonGfx,       $04 ; SPRITE_DUEL_POISON
	gfx_pointer DuelHitGfx,          $09 ; SPRITE_DUEL_HIT
	gfx_pointer DuelDamageGfx,       $12 ; SPRITE_DUEL_DAMAGE
	gfx_pointer DuelThunderGfx,      $09 ; SPRITE_DUEL_THUNDER
	gfx_pointer DuelLightningGfx,    $11 ; SPRITE_DUEL_LIGHTNING
	gfx_pointer DuelSparkGfx,        $03 ; SPRITE_DUEL_SPARK
	gfx_pointer DuelBigLightningGfx, $2d ; SPRITE_DUEL_BIG_LIGHTNING
	gfx_pointer DuelFlameGfx,        $0d ; SPRITE_DUEL_FLAME
	gfx_pointer DuelFireSpinGfx,     $1c ; SPRITE_DUEL_FIRE_SPIN
	gfx_pointer DuelFireBirdGfx,     $4c ; SPRITE_DUEL_FIRE_BIRD
	gfx_pointer DuelWaterDropGfx,    $03 ; SPRITE_DUEL_WATER_DROP
	gfx_pointer DuelWaterGunGfx,     $1b ; SPRITE_DUEL_WATER_GUN
	gfx_pointer DuelWhirlpoolGfx,    $07 ; SPRITE_DUEL_WHIRLPOOL
	gfx_pointer DuelHydroPumpGfx,    $0c ; SPRITE_DUEL_HYDRO_PUMP
	gfx_pointer DuelSnowGfx,         $01 ; SPRITE_DUEL_SNOW
	gfx_pointer DuelPsychicGfx,      $22 ; SPRITE_DUEL_PSYCHIC
	gfx_pointer DuelLeerGfx,         $20 ; SPRITE_DUEL_LEER
	gfx_pointer DuelBeamGfx,         $0a ; SPRITE_DUEL_BEAM
	gfx_pointer DuelHyperBeamGfx,    $25 ; SPRITE_DUEL_HYPER_BEAM
	gfx_pointer DuelRockThrowGfx,    $18 ; SPRITE_DUEL_ROCK_THROW
	gfx_pointer DuelPunchGfx,        $1b ; SPRITE_DUEL_PUNCH
	gfx_pointer DuelStretchKickGfx,  $08 ; SPRITE_DUEL_STRETCH_KICK
	gfx_pointer DuelSlashGfx,        $0d ; SPRITE_DUEL_SLASH
	gfx_pointer DuelWhipGfx,         $22 ; SPRITE_DUEL_WHIP
	gfx_pointer DuelSonicboomGfx,    $0c ; SPRITE_DUEL_SONICBOOM
	gfx_pointer DuelDrillGfx,        $25 ; SPRITE_DUEL_DRILL
	gfx_pointer DuelPotGfx,          $22 ; SPRITE_DUEL_POT
	gfx_pointer DuelBoneGfx,         $0c ; SPRITE_DUEL_BONE
	gfx_pointer DuelPlanetGfx,       $4c ; SPRITE_DUEL_PLANET
	gfx_pointer DuelNeedlesGfx,      $08 ; SPRITE_DUEL_NEEDLES
	gfx_pointer DuelGasGfx,          $07 ; SPRITE_DUEL_GAS
	gfx_pointer DuelPowderGfx,       $01 ; SPRITE_DUEL_POWDER
	gfx_pointer DuelGooGfx,          $1a ; SPRITE_DUEL_GOO
	gfx_pointer DuelBubbleGfx,       $0a ; SPRITE_DUEL_BUBBLE
	gfx_pointer DuelStringGfx,       $2e ; SPRITE_DUEL_STRING
	gfx_pointer DuelHeartGfx,        $08 ; SPRITE_DUEL_HEART
	gfx_pointer DuelLureGfx,         $07 ; SPRITE_DUEL_LURE
	gfx_pointer DuelSkullGfx,        $1c ; SPRITE_DUEL_SKULL
	gfx_pointer DuelSmallStarGfx,    $04 ; SPRITE_DUEL_SMALL_STAR
	gfx_pointer DuelNoteGfx,         $08 ; SPRITE_DUEL_NOTE
	gfx_pointer DuelSoundGfx,        $0b ; SPRITE_DUEL_SOUND
	gfx_pointer DuelPetalGfx,        $01 ; SPRITE_DUEL_PETAL
	gfx_pointer DuelProtectGfx,      $1c ; SPRITE_DUEL_PROTECT
	gfx_pointer DuelBarrierGfx,      $16 ; SPRITE_DUEL_BARRIER
	gfx_pointer DuelSpeedGfx,        $10 ; SPRITE_DUEL_SPEED
	gfx_pointer DuelWhirlwindGfx,    $0f ; SPRITE_DUEL_WHIRLWIND
	gfx_pointer DuelCryGfx,          $07 ; SPRITE_DUEL_CRY
	gfx_pointer DuelQuestionMarkGfx, $0a ; SPRITE_DUEL_QUESTION_MARK
	gfx_pointer DuelExplosionGfx,    $09 ; SPRITE_DUEL_EXPLOSION
	gfx_pointer DuelHealGfx,         $02 ; SPRITE_DUEL_HEAL
	gfx_pointer DuelDrainGfx,        $02 ; SPRITE_DUEL_DRAIN
	gfx_pointer DuelSmallGlowGfx,    $03 ; SPRITE_DUEL_SMALL_GLOW
	gfx_pointer DuelBallGfx,         $08 ; SPRITE_DUEL_BALL
	gfx_pointer DuelCatPawGfx,       $0f ; SPRITE_DUEL_CAT_POW
	gfx_pointer DuelWaveGfx,         $03 ; SPRITE_DUEL_WAVE
	gfx_pointer DuelCardGfx,         $05 ; SPRITE_DUEL_CARD
	gfx_pointer DuelCoinGfx,         $17 ; SPRITE_DUEL_COIN
	gfx_pointer DuelResultGfx,       $36 ; SPRITE_DUEL_RESULT
	gfx_pointer LinkOAMGfx,          $0b ; SPRITE_LINK
	; gfx_pointer PrinterOAMGfx,       $06 ; SPRITE_PRINTER
	; gfx_pointer CardPopOAMGfx,       $16 ; SPRITE_CARD_POP
	; gfx_pointer BoosterPackOAMGfx,   $20 ; SPRITE_BOOSTER_PACK_OAM
	gfx_pointer PressStartGfx,       $14 ; SPRITE_PRESS_START
	gfx_pointer GrassGfx,            $04 ; SPRITE_GRASS
	gfx_pointer FireGfx,             $04 ; SPRITE_FIRE
	gfx_pointer WaterGfx,            $04 ; SPRITE_WATER
	gfx_pointer ColorlessGfx,        $04 ; SPRITE_COLORLESS
	gfx_pointer LightningGfx,        $04 ; SPRITE_LIGHTNING
	gfx_pointer PsychicGfx,          $04 ; SPRITE_PSYCHIC
	gfx_pointer FightingGfx,         $04 ; SPRITE_FIGHTING
	assert_table_length NUM_SPRITES
